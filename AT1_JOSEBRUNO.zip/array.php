<?php
return [
    [
        'colaborador' => 'Bruno',
        'salario_fixo' => 2000.30,
        'venda_semana1' => 1500.10,
        'venda_semana2' => 2250.00,
        'venda_semana3' => 2800.00,
        'venda_semana4' => 1900.00,
    ],
    [
        'colaborador' => 'Antônio',
        'salario_fixo' => 1500.15,
        'venda_semana1' => 150.00,
        'venda_semana2' => 1324.00,
        'venda_semana3' => 1785.85,
        'venda_semana4' => 1900.00,
    ],
    [
        'colaborador' => 'Andrea',
        'salario_fixo' => 2500.30,
        'venda_semana1' => 1500.10,
        'venda_semana2' => 4150.00,
        'venda_semana3' => 1250.60,
        'venda_semana4' => 900.00,
    ],
    [
        'colaborador' => 'Mariana',
        'salario_fixo' => 5000.20,
        'venda_semana1' => 1687.25,
        'venda_semana2' => 875.00,
        'venda_semana3' => 2870.87,
        'venda_semana4' => 1478.25,
    ],
];